Bloggr

===

A WordPress theme for blogs that rely on readability and a newspaper layout.