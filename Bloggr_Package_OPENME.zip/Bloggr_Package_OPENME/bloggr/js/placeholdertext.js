jQuery( function( $ ) {
    // Invoke the plugin
    $('input, textarea').placeholder();
    // That's it, really.
    // Now display a message if the browser supports placeholder natively
   }); 