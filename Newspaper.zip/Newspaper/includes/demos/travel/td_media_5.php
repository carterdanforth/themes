<?php
td_demo_media::add_image_to_media_gallery('td_pic_homepage',            "http://demo_content.tagdiv.com/Newspaper_6/travel/banner.jpg");
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/travel/travel-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header@2x',          'http://demo_content.tagdiv.com/Newspaper_6/travel/travel-header@2x.png');