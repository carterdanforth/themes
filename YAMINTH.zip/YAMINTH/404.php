<?php get_header(); ?>

	<div id="content">

		<div id="posts">

			<div class="search-results"><h2>Error 404: No Page Found!</h2></div>

		</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
