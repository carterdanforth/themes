/**
 * Admin Metabox 
 * Metabox custom jquery functions
 */
 
jQuery(document).ready(function() {
	jQuery('#clean-box-ui-tabs').tabs();
});