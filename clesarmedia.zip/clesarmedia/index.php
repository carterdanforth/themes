<?php get_header(); ?>
<div class="container_content_sidebar">
	<div class="content_sidebar">
		<?php get_template_part( 'category1-content-sidebar'); ?>
	</div>
	<div class="sidebar-layout2">
		<?php get_sidebar(); ?>
	</div>
</div>
<?php get_sidebar('footer'); ?>
<?php get_footer(); ?>