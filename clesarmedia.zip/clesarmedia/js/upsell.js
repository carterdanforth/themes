/**
 * Upsell notice for theme
 */
 
( function( $ ) {
 
	// Add Upgrade Message
	if ('undefined' !== typeof clesarmediaL10n) {
		upsell = $('<a class="clesarmedia-upsell-link"></a>')
			.attr('href', clesarmediaL10n.clesarmediaURL)
			.attr('target', '_blank')
			.text(clesarmediaL10n.clesarmediaLabel)
			.css({
				'display' : 'inline-block',
				'background-color' : '#1b497b',
				'color' : '#fff',
				'text-transform' : 'uppercase',
				'margin-top' : '6px',
				'padding' : '10px 12px',
				'font-size': '12px',
				'letter-spacing': '1px',
				'line-height': '1.5',
				'clear' : 'both'
			})
		;
 
		setTimeout(function () {
			$('#accordion-section-themes h3').append(upsell);
		}, 200);
 
		// Remove accordion click event
		$('.clesarmedia-upsell-link').on('click', function(e) {
			e.stopPropagation();
		});
	}
 
} )( jQuery );