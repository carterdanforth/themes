Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

Theme translation tutorial:
https://themezee.com/docs/theme-translation/

WordPress plugin for translating themes:
http://de.wordpress.org/plugins/loco-translate/

WordPress Codex:
http://codex.wordpress.org/WordPress_in_Your_Language
https://developer.wordpress.org/themes/functionality/localization/
http://codex.wordpress.org/Function_Reference/load_theme_textdomain