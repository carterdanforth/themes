<?php
get_template_part( '/inc/widgets/widget', 'category' );
?>