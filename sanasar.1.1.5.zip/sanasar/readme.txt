I.Theme

Sanasar WordPress Blog Theme, Copyright 2015 WebLoggerz.com

Sanasar is licensed under GNU General Public License V2 or later. You cand find a copy of it in the license.txt file.

Theme Link: http://webloggerz.com/sanasar-wordpress-theme/
Demo Link : http://demo.webloggerz.com/sanasar/

II. Resources

a) Framework - Underscores

sanasar is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
Resource URI: http://underscores.me/
Copyright: Automattic, automattic.com
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html


b) Fonts

Copyright: 2010-2011, Google Fonts.
Resource URI: http://www.google.com/fonts/

c) Icons
The icon set used in sanasar is FontAwesome.
Copyright: Dave Gandy
Resource URI: http://fontawesome.io
License: SIL Open Font License, Version 1.1
License URI: https://scripts.sil.org/OFL?

g) Images
 * Images used in the screenshot and demo are for free to use under GPL License. 
 * Credits - http://pixabay.com/
