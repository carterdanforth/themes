<form role="search" method="get" id="" action="<?php echo esc_url(home_url()); ?>/">
	                        <input type="text" value="" name="s" id="s">
                            <input class="button" type="submit" id="searchsubmit" value="<?php esc_attr_e('Search', 'sanasar'); ?>">
</form>