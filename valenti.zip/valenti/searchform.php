<form role="search" method="get" class="cb-search" action="<?php echo home_url( '/' ); ?>">

    <input type="text" class="cb-search-field" placeholder="" value="" name="s" title="">
    <button class="cb-search-submit" type="submit" value=""><i class="fa fa-search"></i></button>

</form>